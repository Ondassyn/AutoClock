#include <iostream> 
#include "clock.h"

using namespace std;
class am_pm_clock {

	unsigned int hours, minutes, seconds;
	bool		 am;


public:

	am_pm_clock () : 
	
        hours(12),
        minutes(00),
        seconds(00),
        am(true) 
        {}
        
	am_pm_clock(unsigned int hrs, unsigned int mins,
			    unsigned int secs, bool am_val) {
    hours= hrs;
    minutes= mins;
    seconds= secs;
    am= am_val;
    }
                
	am_pm_clock(const am_pm_clock &clock) :
        hours (clock.hours),
        minutes (clock.minutes),
        seconds (clock.seconds),
        am (clock.am)
        
        {}

	am_pm_clock& operator=(const am_pm_clock& clock) {
        hours= clock.hours;
        minutes= clock.minutes;
        seconds= clock.seconds;
        am= clock.am;
        return *this;
    }
    
	void clock:: toggle_am_pm() { 
        if (am) { 
            am= false;
           cout<<"pm";
        } else {
            am=true;
            cout<<"am";
        }
    }

	void clock::reset() {
        hours= 12;
        minutes=00;
        seconds=00;
        am= true;
    }

	void clock:: advance_one_sec()  {  
    
        if (seconds==59 && minutes!= 59 && hours!= 12) {  
            seconds=00;
            minutes= minutes+1;
        } else if (seconds==59 && minutes==59 && hours!=12 ) {
        
            seconds=00;
            minutes=00;
            hours=hours+1;
        } else if (seconds==59 && minutes==59 && hours== 12) {
        
            seconds=00;
            minutes=00;
            hours=01;
            toggle_am_pm();
        } 
        seconds=seconds+1;
    }

	void clock:: advance_n_secs(unsigned int n) {
    
        int s=seconds+n;
        minutes=minutes+s/60;
        seconds=seconds+s%60;
        hours= hours+minutes/60;
        if (hours>12) {
        
            hours=hours%12;
        } 
        if (minutes>60) {
        
            minutes=minutes%60;
            
        }
        if (seconds>60) {
            seconds=seconds%60;
        }
    }

	unsigned int clock:: get_hours() const {
        return hours;
    }

	void clock:: set_hours(unsigned int hrs) {
        cout<<"Enter the hours"<< endl;
        cin>> hrs;
        if (hrs>12) { 
            throw std::invalid_argument("Cannot exceed 12");
        }
    }

	unsigned int clock:: get_minutes() const { 
        return minutes;
    }

	void clock:: set_minutes(unsigned int mins) { 
    
        cout<<"Enter the minutes" << endl;
        cin>> mins;
        if (mins>59) {
            throw std::invalid_argument("Cannot exceed 59");
        }
    }

	unsigned int clock:: get_seconds() const { 
        return seconds;
    }

	void clock::set_seconds(unsigned int secs) { 
        cout<<"Enter the seconds" << endl;
        cin>> secs;
        if (secs>59) {
            throw std::invalid_argument("Cannot exceed 59");
        }
    }
        
	bool clock::is_am() const { 
        if (am) {
            return true;
        } else { 
            return false;
        }
    }
    
	void clock::set_am(bool am_val) {
        if (am_val) {
            cout<<"am";
        } else {
            cout<<"pm";
        }
    }
    
	void print(std::ostream& out) const {
		char buff[11];
		std::sprintf(buff, "%02d:%02d:%02d%cm", hours, minutes, seconds,
				( am ? 'a' : 'p' ));
		out << buff;
	}
	
	~am_pm_clock();
};

inline std::ostream& operator << (std::ostream& out, const am_pm_clock& clock) {
	clock.print(out);
	return out;
}

